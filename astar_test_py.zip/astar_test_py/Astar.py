# -*- coding: utf-8 -*-
import sys

def astar(min_dist,cost):
    #min_dist = findShortestcostLength(mat, src, dest)
    print(min_dist)
    print("uuuu")

    if min_dist != -1:
        print(
            ("The shortest cost from source to destination has length", min_dist)
    else:
        print("Destination cannot be reached from source")

    # コスト配列の表示（numpyを使わないと見づらい）
    print(cost[6][5])
    # 目的地に記入されたコスト
    print(cost[7][5])
    print(cost)
    
    # ゴールから逆順でルート計算
    #########################
    goal =(7,5)
    point_now = goal
    # print("point_now")
    # print(point_now)
    cost_now = cost[7][5]
    route = [goal]
    while cost_now >0:
        
        #上から来た場合
        try:
            if cost[point_now[0] - 1][point_now[1]] == cost_now - 1:
                print("up")
                #更新
                point_now = (point_now[0] - 1, point_now[1])
                cost_now = cost_now - 1
                #記録
                route.append(point_now)
        except: pass
        #下から来た場合
        try:
            if cost[point_now[0] + 1][point_now[1]] == cost_now - 1:
                #更新
                point_now = (point_now[0] + 1, point_now[1])
                print(point_now)
                print("down")
                cost_now = cost_now - 1
                #記録
                route.append(point_now)
        except: pass
        #左から来た場合    
        try:
            if cost[point_now[0]][point_now[1] - 1] == cost_now - 1:
                #更新
                # print(cost_now - 1)
                print("left")
                # print(cost[point_now[0]][point_now[1] - 1])
                point_now = (point_now[0], point_now[1] -1)
                print(point_now)
                cost_now = cost_now - 1
                #記録
                route.append(point_now)
        except: pass
        #右から来た場合
        try:
            if cost[point_now[0]][point_now[1] + 1] == cost_now - 1:
                #更新
                print("bbbb")
                point_now = (point_now[0] , point_now[1]+1)
                cost_now = cost_now - 1
                #記録
                route.append(point_now)
        except: pass

    #ルートを逆順にする
    route = route[::-1]
    print("route_fact")
    print('route\n{}'.format(route))
    #return route

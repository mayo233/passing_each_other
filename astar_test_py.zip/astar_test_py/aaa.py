import sys 


def astar(min_dist, cost):
    
        if min_dist != -1:
            print(
                "The shortest cost from source to destination has length", min_dist)
        else:
            print("Destination cannot be reached from source")
            
    
        print(cost[6][5])

        print(cost[7][5])
        print(cost)

        goal =(7,5)
        point_now = goal
        # print("point_now")
        # print(point_now)
        cost_now = cost[7][5]
        route = [goal]
        
        while cost_now >0:
            try:
                if cost[point_now[0] - 1] [point_now[1]] == cost_now - 1:
                    point_now = (point_now[0] - 1, point_now[1])
                    cost_now = cost_now - 1
                    route.append(point_now)
            except: pass
            
            try:
                if cost[point_now[0] + 1][point_now[1]] == cost_now - 1:
                    point_now = (point_now[0] + 1, point_now[1])
                    cost_now = cost_now - 1
                    route.append(point_now)
            except: pass
            
            try:
                if cost[point_now[0]][point_now[1] - 1] == cost_now - 1:
                    point_now = (point_now[0], point_now[1] - 1)
                    cost_now = cost_now - 1
                    route.append(point_now)
            except: pass
            
            try:
                if cost[point_now[0]][point_now[1] + 1] == cost_now - 1:
                    point_now = (point_now[0], point_now[1] + 1)
                    cost_now = cost_now - 1
                    route.append(point_now)
            except: pass
            
    
        route = route[::-1]
        print(route)
        return route
            

            
            

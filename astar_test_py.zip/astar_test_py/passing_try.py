# -*- coding: utf-8 -*-
import sys
# 現在位置から(x, y)に移動できるか確認してください。 ザ
# 関数は、セルが無効であるか、値が0であるか、すでにアクセスされている場合にfalseを返します。
def isSafe(mat, visited, x, y):
    return 0 <= x < len(mat) and 0 <= y < len(mat[0]) and \
        not (mat[x][y] == 0 or visited[x][y])


# ソースセル(i、j)から行列`mat`で可能な最短ルートを見つける
# 宛先セル`dest`への#。

# `min_dist`は、送信元から宛先までの最長パスの長さを格納します
# これまでに見つかった#であり、`dist`はソースセルから
# 現在のセル(i、j)。


def findShortestcost(mat, visited, i, j, dest, min_dist=sys.maxsize, dist=0):
    global cost

    # 宛先が見つかった場合は、`min_dist`を更新します
    if (i, j) == dest:
        if dist + 1 < cost[i][j]:
            cost[i][j] = dist
        return min(dist, min_dist)

    # 訪問した#セット(i、j)セル
    visited[i][j] = 1

    # は一番下のセルに移動します
    if isSafe(mat, visited, i + 1, j):
        min_dist = findShortestcost(
            mat, visited, i + 1, j, dest, min_dist, dist + 1)
        if dist + 1 < cost[i][j]:
            cost[i][j] = dist

    # は正しいセルに移動します
    if isSafe(mat, visited, i, j + 1):
        min_dist = findShortestcost(
            mat, visited, i, j + 1, dest, min_dist, dist + 1)
        if dist + 1 < cost[i][j]:
            cost[i][j] = dist

    # が一番上のセルに移動します
    if isSafe(mat, visited, i - 1, j):
        min_dist = findShortestcost(
            mat, visited, i - 1, j, dest, min_dist, dist + 1)
        if dist + 1 < cost[i][j]:
            cost[i][j] = dist

    # は左のセルに移動します
    if isSafe(mat, visited, i, j - 1):
        min_dist = findShortestcost(
            mat, visited, i, j - 1, dest, min_dist, dist + 1)
        if dist + 1 < cost[i][j]:
            cost[i][j] = dist

    # バックトラック：訪問したマトリックスから(i、j)を削除します
    visited[i][j] = 0

    return min_dist


# findShortestcost()関数上の#ラッパー
def findShortestcostLength(mat, src, dest):
    global cost

    # はソースセルを取得します(i、j)
    i, j = src

    # 宛先セルを取得(x, y)
    x, y = dest

    # ベースケース
    if not mat or len(mat) == 0 or mat[i][j] == 0 or mat[x][y] == 0:
        return -1

    #`M × N`マトリックス
    (M, N) = (len(mat), len(mat[0]))

    # は、訪問したセルを追跡するために`M × N`マトリックスを構築します
    visited = [[False for _ in range(N)] for _ in range(M)]

    # コスト記録用
    cost = [[999 for _ in range(N)] for _ in range(M)]
    cost[i][j] = 0

    min_dist = findShortestcost(mat, visited, i, j, dest)

    if min_dist != sys.maxsize:
        #print(cost)
        return min_dist,cost
    else:
        return -1
"""
def astar(min_dist,cost):
    #min_dist = findShortestcostLength(mat, src, dest)


    if min_dist != -1:
        print(
            ("The shortest cost from source to destination has length", min_dist)
    else:
        print("Destination cannot be reached from source")

    # コスト配列の表示（numpyを使わないと見づらい）
    print(cost[6][5])
    # 目的地に記入されたコスト
    print(cost[7][5])
    print(cost)
    
    # ゴールから逆順でルート計算
    #########################
    goal =(7,5)
    point_now = goal
    # print("point_now")
    # print(point_now)
    cost_now = cost[7][5]
    route = [goal]
    while cost_now >0:
        
        #上から来た場合
        try:
            if cost[point_now[0] - 1][point_now[1]] == cost_now - 1:
                print("up")
                #更新
                point_now = (point_now[0] - 1, point_now[1])
                cost_now = cost_now - 1
                #記録
                route.append(point_now)
        except: pass
        #下から来た場合
        try:
            if cost[point_now[0] + 1][point_now[1]] == cost_now - 1:
                #更新
                point_now = (point_now[0] + 1, point_now[1])
                print(point_now)
                print("down")
                cost_now = cost_now - 1
                #記録
                route.append(point_now)
        except: pass
        #左から来た場合    
        try:
            if cost[point_now[0]][point_now[1] - 1] == cost_now - 1:
                #更新
                # print(cost_now - 1)
                print("left")
                # print(cost[point_now[0]][point_now[1] - 1])
                point_now = (point_now[0], point_now[1] -1)
                print(point_now)
                cost_now = cost_now - 1
                #記録
                route.append(point_now)
        except: pass
        #右から来た場合
        try:
            if cost[point_now[0]][point_now[1] + 1] == cost_now - 1:
                #更新
                print("bbbb")
                point_now = (point_now[0] , point_now[1]+1)
                cost_now = cost_now - 1
                #記録
                route.append(point_now)
        except: pass

    #ルートを逆順にする
    route = route[::-1]
    print("route_fact")
    print('route\n{}'.format(route))
    return route

import  sys
import Node
import MAP
import robot2
import variable

stop_count =0
stop =False
narrow =False
wait =False
def avoid_robot (agent1_x,agent2_x,agent1_y,agent2_y,count_2,block_h,wait_pos,block_delete,task1, task2):
    
    
    if floor(agent2_y/10) ==block_h and floor(agent2_x/10) ==block_delete  and agent1_x <= block_delete *10 +2.5 and task1 ==15 and task2 ==16:

        variable.collision =True
        space =True  
        wait =True
        
        return agent2_x,agent2_y,stop,narrow,wait

        
    else:
        print(agent1_x, agent1_y)
        wait =False       
            
        return agent2_x,agent2_y,stop,narrow,wait

# -*- coding: utf-8 -*-

def path_1_right_wait(path_11_x, path_11_y,path_21_x, path_21_y):
    
    global agent1_space, agent2_space
     
    for i in range(len(path_11_y)):
        if path_11_x[i] ==block_h-1:
            if path_11_y[i] ==block_delete_num:
                agent1_space =True
                
    for j in range(len(path_21_y)):
        if path_21_x[i] ==block_h-1:
                if path_21_y[i] !=block_delete_num:
                    agent2_space =False
                    
    return agent1_space, agent2_space

def path_2_left_wait(path_11_x, path_11_y,path_21_x, path_21_y):
    
    global agent1_space, agent2_space
     
    if len(path_11_x) > len(path_12_x):
        for i in range(len(path_11_x)):
            print(path_11_x[i])
            
    else:
        for i in range(len(path_11_y)):
            if path_11_x[i] ==block_h-1:
                if path_11_y[i] ==block_delete_num:
                    agent1_space =True
                    
        for j in range(len(path_21_y)):
            if path_21_x[i] ==block_h-1:
                if path_21_y[i] ==block_delete_num:
                    agent2_space =True
                    
    return agent1_space, agent2_space

def path_3_space_wait(path_11_x, path_11_y,path_21_x, path_21_y):
    
    global agent1_space, agent2_space
     
    if len(path_11_x) > len(path_12_x):
        for i in range(len(path_11_x)):
            print(path_11_x[i])
            
    else:
        for i in range(len(path_11_y)):
            if path_11_x[i] ==block_h-1:
                if path_11_y[i] !=block_delete_num:
                    agent1_space =False
                    
        for j in range(len(path_21_y)):
            if path_21_x[i] ==block_h-1:
                if path_21_y[i] ==block_delete_num:
                    agent2_space =True
                    
    return agent1_space, agent2_space

def path_4_under_wait(path_11_x, path_11_y,path_21_x, path_21_y):
    
    global agent1_space, agent2_space
     
    if len(path_11_x) > len(path_12_x):
        for i in range(len(path_11_x)):
            print(path_11_x[i])
            
    else:
        for i in range(len(path_11_y)):
            if path_11_x[i] ==block_h-1:
                if path_11_y[i] !=block_delete_num:
                    agent1_space =False
                    
        for j in range(len(path_21_y)):
            if path_21_x[i] ==block_h-1:
                if path_21_y[i] !=block_delete_num:
                    agent2_space =False
                    
    return agent1_space, agent2_space

def wait_position_flag (agent1,agent2):
    global wait_left, wait_under, wait_space, wait_right
    
    if agent1 ==True:
        if agent2 ==True:
            return wait_left
        else:
            return wait_left
    else:
        if agent2==True:
            return wait_space
        else:
            return wait_under

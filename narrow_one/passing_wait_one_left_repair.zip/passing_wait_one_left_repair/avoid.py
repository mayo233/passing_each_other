import  sys
import Node
import MAP
import robot2
import variable

stop_count =0
stop =False
narrow =False
wait =False
def avoid_robot (agent1_x,agent2_x,agent1_y,agent2_y,count_2,block_h,wait_pos,block_delete,task1, task2):
    global stop_count,stop,narrow,wait
    print(wait_pos)

    if wait_pos =="wait left" and floor(agent2_y/10) ==block_h-2 and floor(agent2_x/10) ==block_delete:    
        
        # variable.collision =True
        # space =True               
    
        return agent2_x,agent2_y,stop,narrow,wait
    
    if wait_pos =="wait right"  and floor(agent2_y/10) ==block_h and floor(agent2_x/10) ==block_delete +1 and agent1_x <= block_delete *10 +2.5 and agent1_y == block_h*10 +4:
    #if wait_pos =="wait right"  and floor(agent2_y/10) ==block_h and floor(agent2_x/10) ==block_delete +1 and agent1_x <= block_delete *10 -2.5:
        wait =True
        return agent2_x,agent2_y,stop,narrow,wait
    
    if wait_pos =="wait space" and floor(agent2_y/10) ==block_h-1 and floor(agent2_x/10) ==block_delete  and agent1_x <=block_h*10 +52.5:
        wait =True
        return agent2_x,agent2_y,stop,narrow,wait
    
    # if (floor(agent2_x/10) - floor(agent1_x/10)) <=1  and floor(agent2_x/10) - floor(agent1_x/10) >=0  or (floor(agent2_y/10) - floor(agent1_y/10) <=1 and floor(agent2_y/10) - floor(agent1_y/10) >=0)and block_h >=15:
    #     #variable.collision =True
    #     #stop=True
    #     narrow =True


    #     return agent2_x,agent2_y,stop,narrow,wait
        # while stop_count >=100000:
        #     stop_count +=1 
        #     print("sasasasasa")
        #     print(stop_count)
        #     print
        #     print(dist (agent1_x ,agent2_x,agent1_y,agent2_y))
          
        #noLoop()
        # print("agent2")
        # print(count_2)
        # robot2.stop=True   #robot1 stop
        # variable.stop=False
        #noLoop()
        # if variable.collision ==False:
        #     variable.pre =count
        #     variable.collision =True
       #  # variable.count =variable.pre
       # # variable.pre +=1
       #  print("stop!!!!")
       #  print(agent2_y-10)
            
       #  return agent2_x,agent2_y-10,stop
        #return agent2_x,agent2_y-10,stop
        
    else:
        #print(floor(agent2_x/10) - floor(agent1_x/10))
        print(agent1_x, agent1_y)
        wait =False        # print("count_2")
        # print(count_2)
        # stop=False
        # if count_2 ==48:
        #     variable.count_2 =48
        #     variable.collision=True
            
        return agent2_x,agent2_y,stop,narrow,wait
        
        
        #return agent1_x
        #noLoop()

        
        #ellipse(variable.pre,agent1_y-10,7,7)

        
        #noLoop()
        #noLoop()
        #ellipse(agent2_x,agent2_y-10,7,7)
    #     if count_collision ==0:
    #         collision =True
    # elif agent2_x - agent1_x <=-20:
    #     variable.stop =False
    # if collision == True:
    #     if space==False:
            
        # print("avoid!!!")
        # #print(agent2)
        # if variable.delete ==False:
        #     variable.temp_x =agent2_x
        #     variable.temp_y= agent2_y
        #     variable.delete =True
        # #ellipse(variable.x_2[7]*10+2.5, variable.y_2[9]*10+4, 7, 7) 
        # ellipse(variable.temp_x,variable.temp_y,7,7)
    
    

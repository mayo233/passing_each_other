# -*- coding: utf-8 -*-
import csv
l=[]
count =0
once_csv =False

def csv_read(count,step):
    #global count
    with open('/home/suzukamayo/passing_no_wait_narrow/C_new.csv') as f:
        reader =csv.reader(f)

        for row in reader:
            if row ==[]:
                csv_write_first(count,step)
                fact =csv_num_check()
                break
            else:
                csv_write(count,step)
                fact =csv_num_check()
                break
                
        return fact
             
def csv_num_check():
    global count
    with open('/home/suzukamayo/passing_no_wait_narrow/C_new.csv') as f:
        reader =csv.reader(f)
        
        for row in reader:
            count +=1
            #print(row)
            l.append(row)
            if count >=100:
                return 74.9

        sort = sorted(l)
        print(sort[0])            
            
def csv_write_first(count,step):
    
    with open('/home/suzukamayo/passing_no_wait_narrow/C_new.csv', 'w') as f:
        writer =csv.writer(f)
        writer.writerow([0.95*(count+step+1)+0.05*(18*2-1)])
                                  
def csv_write(count,step,flag):
    
    if flag ==1:

        with open('/home/suzukamayo/pssing_no_wait_narrow/C_new_8(0.03,0.97)_under_block.csv', 'a') as f:
            writer =csv.writer(f)
            writer.writerow([0.03*(count+step-9)+0.97*(1)])
            
    elif flag ==2:
        with open('/home/suzukamayo/pssing_no_wait_narrow/C_new_8(0.03,0.97)_under_block.csv', 'a') as f:
            writer =csv.writer(f)
            writer.writerow([0.03*(count+step-3)+0.97*(1)])
    else:
        with open('/home/suzukamayo/pssing_no_wait_narrow/C_new_8(0.03,0.97).csv', 'a') as f:
            writer =csv.writer(f)
            writer.writerow([0.03*(count+step-5)+0.97*(1)])
            
            

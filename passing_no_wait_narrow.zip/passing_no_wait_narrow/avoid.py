import  sys
import Node
import MAP
import robot2
import variable

stop_count =0
stop =False
narrow =False
wait =False
def avoid_robot (agent1_x,agent2_x,agent1_y,agent2_y,count_2,block_h,task1,task2):
    global stop_count,stop,narrow,wait

    #print(dist (agent1_x ,agent2_x,agent1_y,agent2_y))
    #if dist (agent1_x ,agent2_x,agent1_y,agent2_y) <=60.11:   #-5  52.1008644    koreninattatoki,count_2+1ninaru  60.11
    #if ((floor(mag(agent2_x,agent2_y))/10) - (floor(mag(agent1_x, agent1_y))/10) ==1) and (agent2_y/10 ==8):
    # print(floor(agent2_x/10))
    # print(floor(agent1_x/10))
    
   # if (floor(agent2_x/10) - floor(agent1_x/10)) <=1  and floor(agent2_x/10) - floor(agent1_x/10) >=0 and block_h <=14:
       
    #agent2 right wait
    if agent1_x >=122.5 and agent1_y ==144 and task2 <=16 :
        wait =True
        
        return agent2_x,agent2_y,stop,narrow,wait
    
    #agent2 right wait
    if agent1_x >=122.5 and agent1_y ==144 and task2 >=16 and task2 >=15:
        wait =True
        
        
        return agent2_x,agent2_y,stop,narrow,wait
    
    #agent2 right no wait
    if agent1_x >=112.5 and agent1_y ==124 :
        wait =False
        return agent2_x,agent2_y,stop,narrow,wait
    
    #agent2 right wait
    if agent1_x >=112.5 and agent1_y ==144 and agent2_x <=162.5 and task2 >=17:
        wait =True
        
        return agent2_x,agent2_y,stop,narrow,wait
    
    #agent2 right no wait
    if agent1_x >=112.5 and agent1_y !=144 :
        wait =False
        return agent2_x,agent2_y,stop,narrow,wait
    
    #agent2 space wait
    if agent1_x >=112.5 and agent1_y ==144  and task1>=16 and task2 <=15:
        wait =True
        
        return agent2_x,agent2_y,stop,narrow,wait
    
    
    #agent2 left wait
    if agent2_x ==152.5 and agent2_y ==124  and task1 <=16:
        variable.collision =True
        space=True
        agent2_x =162.5
        agent2_y =124
        
        return agent2_x,agent2_y,stop,narrow,wait
    
    
    
    elif (floor(agent2_x/10) - floor(agent1_x/10)) <=1  and floor(agent2_x/10) - floor(agent1_x/10) >=0  or (floor(agent2_y/10) - floor(agent1_y/10) <=1 and floor(agent2_y/10) - floor(agent1_y/10) >=0)and block_h >=15:
        #variable.collision =True
        #stop=True
        narrow =True


        return agent2_x,agent2_y,stop,narrow,wait
        # while stop_count >=100000:
        #     stop_count +=1 
        #     print("sasasasasa")
        #     print(stop_count)
        #     print
        #     print(dist (agent1_x ,agent2_x,agent1_y,agent2_y))
          
        #noLoop()
        # print("agent2")
        # print(count_2)
        # robot2.stop=True   #robot1 stop
        # variable.stop=False
        #noLoop()
        # if variable.collision ==False:
        #     variable.pre =count
        #     variable.collision =True
       #  # variable.count =variable.pre
       # # variable.pre +=1
       #  print("stop!!!!")
       #  print(agent2_y-10)
            
       #  return agent2_x,agent2_y-10,stop
        #return agent2_x,agent2_y-10,stop
        
    else:
        #print(floor(agent2_x/10) - floor(agent1_x/10))
        print(agent1_x, agent1_y)
        wait =False        # print("count_2")
        # print(count_2)
        # stop=False
        # if count_2 ==48:
        #     variable.count_2 =48
        #     variable.collision=True
            
        return agent2_x,agent2_y,stop,narrow,wait
        
        
        #return agent1_x
        #noLoop()

        
        #ellipse(variable.pre,agent1_y-10,7,7)

        
        #noLoop()
        #noLoop()
        #ellipse(agent2_x,agent2_y-10,7,7)
    #     if count_collision ==0:
    #         collision =True
    # elif agent2_x - agent1_x <=-20:
    #     variable.stop =False
    # if collision == True:
    #     if space==False:
            
        # print("avoid!!!")
        # #print(agent2)
        # if variable.delete ==False:
        #     variable.temp_x =agent2_x
        #     variable.temp_y= agent2_y
        #     variable.delete =True
        # #ellipse(variable.x_2[7]*10+2.5, variable.y_2[9]*10+4, 7, 7) 
        # ellipse(variable.temp_x,variable.temp_y,7,7)
    
    

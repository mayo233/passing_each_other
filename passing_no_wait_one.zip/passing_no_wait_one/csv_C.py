# -*- coding: utf-8 -*-
import csv
l=[]
count =0
once_csv =False

def csv_read(count,step):
    #global count
    with open('/home/suzukamayo/デスクトップ/passing_no_wait_one/C_new.csv') as f:
        reader =csv.reader(f)

        for row in reader:
            if row ==[]:
                csv_write_first(count,step)
                fact =csv_num_check()
                break
            else:
                csv_write(count,step)
                fact =csv_num_check()
                break
                
        return fact
             
def csv_num_check():
    global count
    with open('/home/suzukamayo/デスクトップ/passing_no_wait_one/C_new.csv') as f:
        reader =csv.reader(f)
        
        for row in reader:
            count +=1
            #print(row)
            l.append(row)
            if count >=100:
                return 74.9

        sort = sorted(l)
        print(sort[0])            
            
def csv_write_first(count,step):
    
    with open('/home/suzukamayo/デスクトップ/passing_no_wait_one/C_new.csv', 'w') as f:
        writer =csv.writer(f)
        writer.writerow([0.95*(count+step+1)+0.05*(18*2-1)])
                                  
def csv_write(count,step):

    with open('/home/suzukamayo/デスクトップ/passing_no_wait_one/C_new.csv', 'a') as f:
        writer =csv.writer(f)
        writer.writerow([0.95*(count+step+1)+0.05*(18*2-1)])

import sys
import Node
import time
import MAP
import robot2
import avoid
import variable
import random
import csv
import csv_C
import math

# 変数宣言
# 4 　　　1列　
# brock14 = [
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
# ]

# 6 　　　2列　
# brock14 = [
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
# ]

# 8 　　　3列　
# brock14 = [
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,1, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
# ]

# 10 　　　4列　
# brock14 = [
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
# ]

# 12 　　　5列　
# brock14 = [
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
# ]

# 14 　　　6列　
# brock14 = [
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
# ]

brock14 = [
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
]


global agent1_flow, agent2_flow, stop_time
global count, play_count_1, play_count_2, count_2
global agent, path_1, path_2,block_h,narrow
global goal,back,back_count,undo,step,step1,step2
global stop, delete, no_stop,pre_x,pre_y,pre_stop,C_old
global agent1_space,agent2_space, wait_right,wait_left,wait_space,wait_under,once

x_1 = []
y_1 = []
x_2 = []
y_2 = []
path_1 = []
path_2 = []
agent = []

goal = False
goal_2 = False
stop = False
no_stop = True
delete = False
pre_stop=False
once =False
once_2 =False
wait =False
narrow =False
agent1_space=False
agent2_space=False
agent1_flow =False
agent2_flow =False
# wait_right=False
# wait_left=False
# wait_space=False
# wait_under=False

agent1 = 490
undo=0
count = 0
back=0
step =0
back_count =0
count_2 = 0
C_old=74.95
play_count_1 = 0
play_count_2 = 0
stop_time = 0
pre_x =0
pre_y =0
step1 =0
step2 =0
block_delete_num=[16,5,-1]
block_h=4

variable.num1 = random.randint(1, 18)
variable.num2 = random.randint(1, 18) 

# print(variable.num2)
# variable.num1 = 1
#variable.num2 = 15

def path_search11():

    # エージェント１の経路探索
    global play_count_1  # 関数の実行回数
    print("agent1 task")
    print(brock14)
    print(variable.num1)
    
    start = (8, 0)  # スタート地点  49,0
    end = (block_h,  variable.num1)  # タスク地点 (goal)  8,7
    path = Node.astar(brock14, start, end)  # A_starで探索された経路
    print("agent1")
    print(path)

    # 探索された経路のx,yを各配列に格納
    for i in range(len(path)):
        x_1.append(path[i][1])
        y_1.append(path[i][0])

    return x_1,y_1,path

def path_search12():
    
    # if variable.num1 >=18:
    
    #     start = (block_h,  variable.num1)  # スタート地点  8,7
    #     end = (0, 5)  # タスク地点 (goal) 49,0
    #     path = Node.astar(brock14, start, end)  # A_starで探索された経路

    #     for i in range(len(path)):
    #         x_1.append(path[i][1])
    #         y_1.append(path[i][0])
            
    #     start = (0,  5)  # スタート地点  8,7
    #     end = (0, 19)  # タスク地点 (goal) 49,0
    #     path = Node.astar(brock14, start, end)  # A_starで探索された経路

    #     for i in range(len(path)):
    #         x_1.append(path[i][1])
    #         y_1.append(path[i][0])
            
    # else:
    start = (block_h, variable.num1)  # スタート地点  8,7
    end = (0, 19)  # タスク地点 (goal) 49,0
    path = Node.astar(brock14, start, end)  # A_starで探索された経路

    for i in range(len(path)):
        x_1.append(path[i][1])
        y_1.append(path[i][0])
            
    return x_1,y_1,path
        
def path_search21():
    print("agent2 task")
    print(variable.num2)

    start = (0, 19)  # スタート地点 0,49
    end = (block_h, variable.num2)  # タスク地点 (goal)  8,31
    path = Node.astar(brock14, start, end)  # A_starで探索された経路
   # print(path)

    for i in range(len(path)):
        x_2.append(path[i][1])
        y_2.append(path[i][0])
        
    return x_2,y_2,path

def path_search22():
    start = (block_h, variable.num2)  #  スタート地点
    end = (8,0)  # タスク地点 (goal)
    path = Node.astar(brock14, start, end)  # A_starで探索された経路
    
    for i in range(len(path)):
        x_2.append(path[i][1])
        y_2.append(path[i][0])
        
    return x_2,y_2,path

def path_1_right_wait(path_11, path_21):
    
    global agent1_space, agent2_space
    
    for i in range(len(path_11)):
       if path_11[i][0] ==block_h-1:
           for j in range(len(block_delete_num)):
               if path_11[i][1] ==block_delete_num[j]:
                   agent1_space =True

    for i in range(len(path_21)):
       if path_21[i][0] ==block_h-1:
           for j in range(len(block_delete_num)):
               if path_11[i][1] ==block_delete_num[j]:
                   agent2_space =False
               
    if agent1_space ==True and agent2_space ==False:
        return agent1_space, agent2_space,1
    else:        
        return agent1_space, agent2_space,0

def path_2_left_wait(path_11, path_21):
    
    global agent1_space, agent2_space
    
    for i in range(len(path_11)):
       if path_11[i][0] ==block_h-1:
           for j in range(len(block_delete_num)):
               if path_11[i][1] ==block_delete_num[j]:
                   agent1_space =True
               
    for i in range(len(path_21)):
       if path_21[i][0] ==block_h-1:
           for j in range(len(block_delete_num)):
               if path_21[i][1] ==block_delete_num[j]:
                  agent2_space =True

    if agent1_space ==True and agent2_space ==True:
        return agent1_space, agent2_space,1
    else:        
        return agent1_space, agent2_space,0

def path_3_space_wait(path_11, path_21):
    
    global agent1_space, agent2_space
    
    for i in range(len(path_11)):
       if path_11[i][0] ==block_h-1:
           for j in range(len(block_delete_num)):
               if path_11[i][1] !=block_delete_num[j]:
                   agent1_space =False
               
    for i in range(len(path_21)):
       if path_21[i][0] ==block_h-1:
           for j in range(len(block_delete_num)):
               if path_21[i][1] ==block_delete_num[j]:
                   agent2_space =True
               
    if agent1_space ==False and agent2_space ==True:
        return agent1_space, agent2_space,1
    else:        
        return agent1_space, agent2_space,0

def path_4_under_wait(path_11, path_21):
    
    global agent1_space, agent2_space
    
    for i in range(len(path_11)):
       if path_11[i][0] ==block_h-1:
           for j in range(len(block_delete_num)):
               if path_11[i][1] !=block_delete_num[j]:
                   agent1_space =False
               
    for i in range(len(path_21)):
       if path_21[i][0] ==block_h-1:
           for j in range(len(block_delete_num)):
               if path_21[i][1] !=block_delete_num[j]:
                   agent2_space =False
               
    if agent1_space ==False and agent2_space ==False:
        return agent1_space, agent2_space,1
    else:        
        return agent1_space, agent2_space,0
                   
    return agent1_space, agent2_space

def wait_position_flag (agent1,agent2,flag):

    if flag ==1:
        if agent1 ==True:
            if agent2 ==True:
                return "wait left"
            else:
                return "wait right"
        else:
            if agent2==True:
                return "wait space"
            else:
                return "wait under"
            
def agent_move1():

    global count, goal,step1,agent1_flow,agent2_flow,once,agent1,agent2,C_old
    
    if count <= len(x_1) - 1 and goal == False and variable.stop==False:
        # fill(155, 100, 100)
        # ellipse(x_1[count] * 10 + 2.5, y_1[count] * 10 + 4, 7, 7)  # エージェント１
        
        if count !=len(x_1)-1:
           count+=1     
            
        #if x_1[count] * 10 + 2.5 == 192.5 and y_1[count] * 10 + 4 ==4:
        if count ==len(x_1)-1:
            agent1_flow=True
            print("agent1step")     
            print(count)
            
        if agent1_flow ==True and agent2_flow==True and once ==False:
            print("flow time")
            print(step)
            
            print("Evaluation function")
            if agent1 ==True and agent2 ==True:
                print("1masu")
                print(0.95*(count+step+1)+0.05*(18*2-2))
                #C_new=csv_C.csv_read(count,step)
                print("C_new")
                print(C_new)
                                
            else:
                print(0.95*(count+step)+0.05*(18*2-2))
                C_new=csv_C.csv_read(count,step)
                print("C_new")
                print(C_new)
                
            # if C_old>C_new:
            #     C_old =C_new
            #     block_delete_num.append(block_delete_num[-1]-2)
                
            # else:
            #     print("finish!!!!")
            #     print(block_delete_num)
                            
            print("agent1 explored route")
            print(path_11)            
            
            print("agent2 explored route")
            print(path_21)
            print(path_22)

            print("block num")
            if brock14 !=None:
                print("125")
                
            once =True
            sys.exit()
            
def agent_move2(path_11,path_1,path_21,path_22,wait_pos):
    global count_2, goal_2, stop_time,stop,back,no_stop,back_count,pre_x,pre_y,pre_stop,block_num_pre,undo,step,narrow,wait,agent2_flow,agent1_flow,once

    if (variable.count_2 !=len(x_2)-1 and (variable.collision==False)):
                    
        if wait ==False:
            variable.count_2 +=1
            
        if x_2[variable.count_2]*10+2.5 <=2.5 and y_2[variable.count_2]*10+4 ==84:
            agent2_flow =True
            
            

            
        # if x_2[variable.count_2]*10+2.5 ==:
        #     agent2 =True
            #noLoop()
        
        # if ((math.floor(mag(x_2[variable.count_2]*10+2.5,y_2[variable.count_2]*10+4))/10) - (math.floor(mag(x_1[count]*10+2.5, y_1[count]*10+4))/10) ==2  and variable.count_2 >=10): 
        #     back =variable.count_2
        #     print("back")
        #     print(back)
    #else:
        #print("stoppped")
        # print("count_2")
        # print(variable.count_2)
        #pre_y -10
        #variable.count_2 =0
        # print("ooooo")
        # print(variable.count_2)
        # print(x_2[variable.count_2]*10)
        # #print(print(math.floor(mag(x_2[variable.count_2]*10+2.5,y_2[variable.count_2]*10+4))/10))
        
        # variable.count_2 =48
        
        
    #elif robot2.stop==True:
    #print(variable.count_2)
    #if no_stop ==False:
    if back !=0:
        variable.count_2 =back

    pre_x,pre_y,pre_stop,narrow,wait=avoid.avoid_robot(x_1[count]*10+2.5,x_2[variable.count_2]*10+2.5,y_1[count]*10+4,y_2[variable.count_2]*10+4,variable.count_2,block_h,wait_pos,block_delete_num,variable.num1, variable.num2)
    # print(math.floor(x_2[variable.count_2] * 10 + 2.5)/10)
    # print(math.floor(x_1[count] * 10 + 2.5)/10)
    #pre_x,pre_y,pre_stop=avoid.avoid_robot(math.floor(x_1[count]*10+2.5)/10, math.floor(x_2[variable.count_2]*10+2.5)/10,y_1[count]*10+4,y_2[variable.count_2]*10+4,variable.count_2)
    #fill(155, 100, 100)

    if variable.collision ==True:
        print("block_delete_count")
        agent2_x =pre_x -6.5
        
        undo =10.5

        #variable.block_num_pre =(math.floor(agent2_x)/10)
        #print(variable.block_num_pre)
        agent2_y =pre_y

        variable.stop_time +=1
        if variable.stop_time >=21:
            agent2_x =pre_x
            variable.collision=False

    else:
  
        agent2_x =pre_x 
        agent2_y =pre_y
        
        if math.floor((x_2[variable.count_2] * 10 + 2.5)/10) <=1:
            agent2_x =pre_x +6  # 0,49/6
            
        # if narrow ==True:
        #     noLoop()
            
            

        
    # fill(200,200,300)
    # ellipse(agent2_x, agent2_y, 7, 7)
    step +=1
    print("agent2step")
    print(step)
    
    # if pre_stop==True and pre_y ==74:
    #     variable.collision =True
        
    
        # print("robot2")
        # print(x_2[count_2]*10+2.5)
        #print(count_2)
        
        # if variable.stop==True:
        #     fill(155, 100, 100)
        #     ellipse(x_1[count] * 10 + 2.5, y_1[count] * 10 + 4, 7, 7)
    #else:
        
            # fill(155, 100, 100)
            # ellipse(pre, y_2[count_2] * 10 + 4, 7, 7)
        
        # println(x_1[count]*10+2.5)
        
    #     if count_2 >= len(x_2):
    #         goal_2 = True
    

    # if goal_2 == True:

    #     fill(155, 100, 100)
    #     ellipse(x_2[-1] * 10 + 2.5, y_2[-1] * 10 + 4, 7, 7)  # エージェント2

    #if variable.stop == False:

        
        # print("------")
        # if count_2 != len(x_2) -1:
        #      count_2 += 1
        #      print("tuuzyou")
        #      print(count_2)
        # else:
        #      count_2 =len(x_2) -1
        # print(x_2[count_2] * 10 + 2.5)
    # else:
    #     print(x_2[count_2] * 10 + 2.5)
    #     #noLoop()
    
    #     # if ((millis()/1000 - stop_time)==1):
    #     #     print(millis()/1000 - stop_time)
    #     variable.pre =x_2[count_2]*10+2.5  #障害物がある所に移動
    #     #ellipse(pre, y_2[count_2] * 10 + 4 +back, 7, 7)
    #     back +=10            
    #     ellipse(variable.pre, y_1[count_2] * 10 + 4, 7, 7) 
        #衝突回避をするために移動したら2秒ほど停止する
        # if back ==0 and back_count !=3:
        #     back =-10
        #     back_count +=1
            
        #衝突回避をした後，ゴール地点まで移動する
        # if back_count >=2 and back >=0:
        #        ellipse(x_1[count_2-1]*10+2.5, y_1[count_2-1] * 10 + 4, 7, 7)        
        #        if count_2 !=len(x_2)-1:
        #            count_2 +=1
        #        #count_2+=1
        #        print("avoidddddr")
        #        print([count_2])

        # else :
        #        ellipse(variable.pre, y_2[count_2] * 10 + 4 +back, 7, 7)  #衝突回避を行う        
            
        # back +=10
        # print(back)
        # if back ==10:
        #     noLoop()
        #variable.stop_time+=1
        #back +=10
        
        # back+=10
        # print(back)
        # if back==0:
        #     noLoop()
    
    
# def setup():
#     size(200, 90)
#     frameRate(3)


# def draw():
#     background(0)
#     textSize(40)

#     MAP.make_brock(variable.num1, variable.num2,block_h)
#     agent_move1()
#     agent_move2(path_11,path_12,path_21,path_22, wait_pos)

    
if __name__ == '__main__':
    path_11_x, path_11_y,path_11=path_search11()

    path_12_x, path_12_y,path_12=path_search12()
    
    path_21_x, path_21_y,path_21=path_search21()


    path_22_x, path_22_y,path_22=path_search22()
    
    path_11.extend(path_12)
    path_21.extend(path_22)
    
    agent1,agent2,flag =path_1_right_wait(path_11,path_21)
    if flag==1:
        wait_pos=wait_position_flag(agent1, agent2,flag)        
    
    agent1,agent2,flag =path_2_left_wait(path_11,path_21)
    if flag==1:
        wait_pos=wait_position_flag(agent1, agent2,flag)
    
    agent1,agent2,flag =path_3_space_wait(path_11,path_21)
    if flag==1:
        wait_pos=wait_position_flag(agent1, agent2,flag)
        
    agent1,agent2,flag =path_4_under_wait(path_11,path_21)
    if flag==1:
        wait_pos=wait_position_flag(agent1, agent2,flag)
        

       
    while True:
        #MAP.make_brock(variable.num1, variable.num2,block_h)
        agent_move1()
        agent_move2(path_11,path_12,path_21,path_22, wait_pos)
    



    
    
    
    
    
    
    
    

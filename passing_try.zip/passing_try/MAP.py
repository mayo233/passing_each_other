# -*- coding: utf-8 -*-
import variable

# ブロック作成を行う関数
def make_brock(num_1, num_2):
    for i in range(20):
        for j in range(20):
            
            # if variable.once ==False:
            #     variable.num_task1 =num_1           
            #     variable.once =True
            
            # if variable.two ==False:
            #     variable.num_task2 =num_2              
            #     variable.two =True
           
            if (i == 0 and j == 19):  # 赤色　ゴール地点とスタート地点  ピンク 97,67,65   紫 167,87,168
                fill(250, 20, 0)
                rect(j * 10, i * 10, 10, 10)
                
            elif (i ==19 and j ==0):
                fill(0, 0, 255)
                rect(j * 10, i * 10, 10, 10)
                

            elif (i == 4 and j == num_1 ):  # スタートとゴール地点   エージェント１ タスクをランダムに割り当てる
                fill(167, 87, 168)
                #print("bbbb")
                rect(j * 10, i * 10, 10, 10)
                
            # #タスクをランダムに割り当てる　エージェント２の
            elif ((i == 4 and j ==num_2)):  # 中間地点
                fill(234, 145, 152)
                rect(j * 10, i * 10, 10, 10)

            elif variable.brock[i][j] == 0:
                fill(255, 255, 255)  # 白いブロックにする
                rect(j * 10, i * 10, 10, 10)
                
            elif variable.brock[i][j] ==1:
                fill(0, 0, 0)  # 白いブロックにする
                rect(j * 10, i * 10, 10, 10)
                
                
    return variable.num_task1, variable.num_task2

            # elif variable.brock[i][j] == 1:
            #     fill(0, 0, 0)  # 黒いブロックにする
                    
            #     if variable.stop_time >=1:
            #         fill(255,255,255)
            #         # print("iiiiiii")
            #         # print(variable.block_num_pre)
            #         rect(variable.block_num_pre*10,70,10,10)
            #     else:   
            #         rect(j * 10, i * 10, 10, 10)
                
                
            # print("block_num")
            # print(block_num)
                
                
